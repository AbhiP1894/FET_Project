//checking user login
function userLogin() {
  let username = document.getElementById("userEmail").value;
  let password = document.getElementById("userPw").value;
  let result = JSON.parse(checkLoginCredentials());
  
  if (username == '') {
    alert("Enter username");
  } else if (password == '') {
    alert("Enter password");
  } 
  else {
    let resultObject = search(username, password, result);
    userExist(resultObject);
  }
}

function checkLoginCredentials() {
  var jsonResult = null;
  $.ajax({
    async: false,
    url:
      loginUrl,
    type: "GET",
    success: function (data) {
      jsonResult = JSON.stringify(data);
    },
    error: function (error) {
      alert(`Error ${error}`);
    }
  });
  return jsonResult;
}

function userExist(resultObject) {
  if (resultObject) {
    localStorage.setItem("userCredentials", JSON.stringify(resultObject));
    if (resultObject.role == 'user' || resultObject.role == null || resultObject.role == '') {
      alert("Login Successful");
      window.open('forum.html');
    }
    else if (resultObject.role == 'admin') {
      alert("Login Successful");
      window.open('adminHome.html');
    }
    else {
      alert("Entered credentials are wrong");
    }
  }
}

function search(username, password, inputArray) {
  let result = null;
  for (let i = 0; i < inputArray.length; i++) {
    let uName = inputArray[i].username;
    let uPass = inputArray[i].password;
    if (uName == username && uPass == password) {
      result = inputArray[i];
      break;
    }
  }
  return result;
}
