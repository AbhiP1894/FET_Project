$(function () {
    $("#nav").load("navbar.html");
  });
  
  $(function () {
    $("#footer").load("footer.html");
  });