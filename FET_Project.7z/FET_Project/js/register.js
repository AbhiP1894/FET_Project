$('#pwd,#cpwd').on('keyup', function () {
    if ($('#pwd').val() == $('#cpwd').val()) {
      $('#msg').html('Matching').css('color', 'green');
    }
    else
      $('#msg').html('Not Matching').css('color', 'red');
  });
// let resultObject = search(username, password, emailid, confirmPassword, result);
//   if (resultObject) {
//       localStorage.setItem("userCredentials", JSON.stringify(resultObject));
//       if (resultObject.name == ' ' || resultObject.name == null) {
//           alert("Please Enter Username");

//       }
//     }
//   else if (resultObject.pwd == null || resultObject.pwd == '') {
//       alert("Please enter password");

//   }
//   else if (resultObject.cpwd == null || resultObject.cpwd == '') {
//       alert("Please enter password");

//   }
//   else if (resultObject.email == null || resultObject.email == '') {
//       alert("Please enter emailid");

//   }
 
//   else {
//       alert("Registration successful");
//       window.open("login.html");
//   }
//   function search(username, password, emailid, confirmPassword, inputArray) {
//     let result = null;
//      for (let i = 0; i < inputArray.length; i++) {
//        if (inputArray[i].username == username && inputArray[i].password == password && inputArray[i].emailid==emailid && inputArray[i].confirmPassword==confirmPassword) {
//               result = inputArray[i];
//               break;
//           }
//       }
//       return result;
//   }
