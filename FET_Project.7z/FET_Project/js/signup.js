function signUp() {

    let username = document.getElementById("email").value;
    let password = document.getElementById("pwd").value;
    let name = document.getElementById("name").value;
    let confirmPassword = document.getElementById("cpwd").value;
    debugger
    if (username == '') {
        alert("Enter username");
    } else if (name == '') {
        alert("Enter name");
    } else if (password == '') {
        alert("Enter password");
    }  else if (confirmPassword == '') {
        alert("Enter confirmPassword");
    } else {
        let paylod =
        {
            "username": username,
            "pasword": password,
            "name": name,
            "confirmPassword": confirmPassword

        }
        insertNewCredentials(paylod);
    }
}
function insertNewCredentials(paylod) {
    var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
    xmlhttp.open("POST", "http://localhost:3333/login");
    xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xmlhttp.send(JSON.stringify(paylod));
    window.open("login.html");

}

