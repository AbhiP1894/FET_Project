var qusetionsListResult = [];
var currentUser = null;
function updateAnswer(questionId, qusetionAnswer, condition){
    currentUser =  getCurrenyUserLogin();
    let resultObject  = qusetionsListResult.find(x => x.id === questionId);
    let qusetionAnswerArray = resultObject.Answer;
    let Comment = resultObject.Comment;
    let Like = resultObject.Like;
    if(condition == 1){
    qusetionAnswerArray.push({Answer: qusetionAnswer});
    } else if(condition == 2){
        Comment.push({Comment: qusetionAnswer});
    } else if(condition == 3){
        Like.push({Like: qusetionAnswer}); 
    }
    let payload = { 
    categoryName: resultObject.categoryName,
    qusetionName: resultObject.qusetionName,
    categoryId: resultObject.categoryId,
    approved: resultObject.approved,
    createdDate: resultObject.createdDate,
    Answer:qusetionAnswerArray,
    Comment:Comment,
    Like:Like,
    createdBy: currentUser.username
}
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open("PUT", 'http://localhost:5555/Qusetions/'+questionId, true);
    xmlHttp.setRequestHeader('Content-type','application/json; charset=utf-8');
    xmlHttp.onload = function () {
        var result = JSON.parse(xmlHttp.responseText);
    if(result){
        if(condition == 1){
        alert("Successfully Answered");
        } else if(condition == 2){
            alert("Successfully Commented");
        } else if(condition == 3){
            alert("Successfully Liked");
        }
        getQusetions();
    }
    }
    xmlHttp.send(JSON.stringify(payload));
}

function sendAnswer(questionId){
let answer = document.getElementById('answer'+questionId).value;
updateAnswer(questionId, answer, 1);
}
function sendComments(questionId){
    let comment = document.getElementById('comments'+questionId).value;
    updateAnswer(questionId, comment, 2);
}
function seneLikes(questionId){
    updateAnswer(questionId, 'Liked', 3);
    
}
function getQusetions() {
    qusetionsListResult = JSON.parse(QusetionsList());
    let str = '<div class="container1" style="margin-left:100px;margin-top:10px;margin-bottom:3rem;"><div class="row">';
    for (let i = 0; i < qusetionsListResult.length; i++) {
        if(qusetionsListResult[i].approved == 'Approved by Admin'){
        str += 
         '<div class="card col-md-4" style="text-align:left; margin-left:100px;margin-bottom:3rem;">';
            
             str += '<p style="margin:0.5rem;">' + (i+1) +'. Question</p>'+
                '<h5 class="card-title"style="margin:0.5rem;">Category: '+qusetionsListResult[i].categoryName +'</h5>'+
                '<p class="card-text"style="margin:0.5rem;">Question: '+qusetionsListResult[i].qusetionName +'</p>'+
                '<p class="card-text"style="margin:0.5rem;">Action: '+qusetionsListResult[i].approved +'</p>'+
                '<p class="card-text"style="margin:0.5rem;"><small class="text-muted"> Qusetion Created: '+timeDifference(new Date(), new Date(qusetionsListResult[i].createdDate)) +'</small></p>';
                if(qusetionsListResult[i].Answer.length > 0){
                    str += 'Answers: '  
                    for (let j = 0; j < qusetionsListResult[i].Answer.length; j++) {  
                        str +='<p style="margin:0.7rem;text-align:left;font-size: large;">'+(j+1)+'. '+qusetionsListResult[i].Answer[j].Answer+' - Answered by - '+qusetionsListResult[i].createdBy+'</p>';

                    }
                    
                }
                if(qusetionsListResult[i].Comment.length > 0){
                    str += 'Comments: '  
                    for (let j = 0; j < qusetionsListResult[i].Comment.length; j++) {  
                        str +='<p style="margin:0.3rem;">'+(j+1)+'. '+qusetionsListResult[i].Comment[j].Comment+' - Comentted by - '+qusetionsListResult[i].createdBy+'</p>';

                    }
                }
                if(qusetionsListResult[i].Like.length > 0){
                    str += 'Likes: ' + qusetionsListResult[i].Like.length; 
                    for (let j = 0; j < qusetionsListResult[i].Like.length; j++) {  
                        str +='<p style="margin:0.3rem;">'+(j+1)+'. Liked by - '+qusetionsListResult[i].createdBy+'</p>';

                    }
                }
                str +='<i class="fas fa-pencil-alt prefix"style="margin:0.3rem;">Answer:</i><textarea id="answer'+qusetionsListResult[i].id+'"  class="md-textarea form-control" rows="3" placeholder="Write Your Answer Here.."></textarea>';
                str+='<button type="button"class="btn btn-primary" style="margin-left:10px;margin-top:10px;margin-bottom:20px;"id="answer'+qusetionsListResult[i].id+'" onclick="sendAnswer('+qusetionsListResult[i].id+')">Send Answer</button>';
                str+='<div><textarea id="comments'+qusetionsListResult[i].id+'" placeholder="Write Comment Here.." class="md-textarea form-control" rows="2"></textarea>'+
                '<button type="button"class="btn btn-info"  style="margin-left:10px;margin-top:10px;margin-bottom:20px;" id="comments'+qusetionsListResult[i].id+'" onclick="sendComments('+qusetionsListResult[i].id+')">Send Comments</button>'+
                '<button id="like'+qusetionsListResult[i].id+'" onClick="seneLikes('+qusetionsListResult[i].id+')" class="btn btn-success px-3" style="margin-left:10px; margin-top:10px;margin-bottom:20px;"> '+
                '<i class="far fa-thumbs-up"  aria-hidden="true"></i></button></div></div>';
            }
            }
            str += '</div></div>';
           
 
    document.getElementById("qusetions").innerHTML = str;
}
// function getCurrentUser(){
//     currentUser =  getCurrentUserLogin();
//    document.getElementById("currentUser").innerHTML = currentUser.name;
// }

// getCurrentUser();
getQusetions();
