// function getQusetions() {
//     qusetionsListResult = JSON.parse(QusetionsList());
//     let str = '<div class="container1"><div class="row">';
//     for (let i = 0; i < qusetionsListResult.length; i++) {
//         if(qusetionsListResult[i].approved == 'Approved by Admin'){
//         str +=
//          '<div class="card " style="text-align:left;background-color:lightblue;">'+
//             '<img src="../Images/question.png"  style="width:130px;height:130px" alt="...">';
//              str += '<p>' + (i+1) +'. Question</p>'+
//                 '<h5 class="card-title">Category: '+qusetionsListResult[i].categoryName +'</h5>'+
//                 '<p class="card-text">Question: '+qusetionsListResult[i].qusetionName +'</p>'+
//                 '<p class="card-text">Action: '+qusetionsListResult[i].approved +'</p>'+
//                 '<p class="card-text"><small class="text-muted"> Qusetion Created: '+timeDifference(new Date(), new Date(qusetionsListResult[i].createdDate)) +'</small></p>';
//                 if(qusetionsListResult[i].Answer.length > 0){
//                     str += 'Answers: '  
//                     for (let j = 0; j < qusetionsListResult[i].Answer.length; j++) {  
//                         str +='<p>'+(j+1)+'. '+qusetionsListResult[i].Answer[j].Answer+'</p>';
//                         str +='<div id="comment"><pre></pre></div>'
//                         str+= '<div class="col-md-6" > <input id="comment"  placeholder="Add Comment"></input>'+
//                         '<button id="btn1" type="submit" style="width:90px; height:30px; display:inline; margin-left: 10px;" class="btn btn-primary btn-sm">Post</button>'+
//                        '<button id="like" class="btn bg-primary" style="margin-left:10px; width:40px; "> <span id="icon" ><i class="fa-solid fa-thumbs-up"></i></span></button> </div>';
//                     }
//                 }
//                 str += '</div>';
//             }
//             }
//             str += '</div></div>';
           
 
//     document.getElementById("qusetions").innerHTML = str;
  
// }

// // getQusetions();

// function QusetionsList() {
//     var xmlHttp = new XMLHttpRequest();
//     xmlHttp.open("GET", 'http://localhost:5555/Qusetions', false); // false for synchronous request
//     xmlHttp.send(null);
//     return xmlHttp.responseText;
// }

function getAllCategories()  {
    qusetionsListResult = JSON.parse(QusetionsList());
    let str = '<div class="container1 "><div class="row">';
    for (let i = 0; i < qusetionsListResult.length; i++) {
        if(qusetionsListResult[i].approved == 'Approved by Admin'){
        str +=
         '<div class="card col-md-5" style="text-align:left; margin-left:80px; justify-self:center;"">'+
            '<img src="../Images/question.png"  style="width:160px;height:160px" alt="...">';
             str += '<p>' + (i+1) +'. Question</p>'+
                '<h5 class="card-title">Category: '+qusetionsListResult[i].categoryName +'</h5>'+
                '<p class="card-text">Question: '+qusetionsListResult[i].qusetionName +'</p>'+
                '<p class="card-text">Action: '+qusetionsListResult[i].approved +'</p>'+
                '<p class="card-text"><small class="text-muted"> Qusetion Created: '+timeDifference(new Date(), new Date(qusetionsListResult[i].createdDate)) +'</small></p>';
                if(qusetionsListResult[i].Answer.length > 0){
                    str += 'Answers: '  
                    for (let j = 0; j < qusetionsListResult[i].Answer.length; j++) {  
                        str +='<p>'+(j+1)+'. '+qusetionsListResult[i].Answer[j].Answer+'</p>';
                        
                        str+= '<div class="col-md-6" > <input id="comment"  placeholder="Add Comment"></input>'+
                        '<button id="btn" type="submit" style="width:90px; height:30px; display:inline; margin-left: 10px;" class="btn btn-primary btn-sm">Post</button>'+
                        '<button id="clicks" onClick="onClick()" class="btn bg-primary" style="margin-left:10px; height:50px; width:50px; "> <span id="icon" ><i class="fa-solid fa-thumbs-up"></i></span></button> </div>';
                    }
                }
                str += '</div>';
            }
            }
            str += '</div></div>';
           
   document.getElementById("container1").innerHTML = str;
}

function searchByCategory(categoryId) {
    // alert("Selected Category is "+categoryId);
    let qusetionsList = JSON.parse(QusetionsList());
    let filteredQuestionList = [];
    let str = "";
    for (let i = 0; i < qusetionsList.length; i++) {
      //str += "<div >" + qusetionsList[i].qusetionName + "</div><br>";
      if (qusetionsList[i].categoryName == categoryId) {
        filteredQuestionList.push(qusetionsList[i]);
      }
    }
    console.log("Java Filtered" + JSON.stringify(filteredQuestionList));
  //   qusetionsList = JSON.parse(filteredQuestionList);
    str = "";
    for (let i = 0; i < filteredQuestionList.length; i++) {
      //str += "<div >" + qusetionsList[i].qusetionName + "</div><br>";
  
      str +=
      '<div class="card col-md-4" style="text-align:left">'+
         '<img src="../Images/question.png"  style="width:30px;height:30px" alt="...">';
          str += '<p>' + (i+1) +'. Question</p>'+
             '<h5 class="card-title">Category: '+filteredQuestionList[i].categoryName +'</h5>'+
             '<p class="card-text">Question: '+filteredQuestionList[i].qusetionName +'</p>'+
             '<p class="card-text">Action: '+filteredQuestionList[i].approved +'</p>'+
             '<p class="card-text"><small class="text-muted"> Qusetion Created: '+timeDifference(new Date(), new Date(qusetionsListResult[i].createdDate)) +'</small></p>';
             if(qusetionsListResult[i].Answer.length > 0){
                 str += 'Answers: '  
                 for (let j = 0; j < filteredQuestionList[i].Answer.length; j++) {  
                     str +='<p>'+(j+1)+'. '+filteredQuestionList[i].Answer[j].Answer+'</p>';
                     str+= '<div class="col-md-6" > <input id="comment"  placeholder="Add Comment"></input>'+
                     '<button id="btn" type="submit" style="width:90px; height:30px; display:inline; margin-left: 10px;" class="btn btn-primary btn-sm">Post</button>'+
                     '<button id="clicks" onClick="onClick()" class="btn bg-primary" style="margin-left:10px; height:30px; width:50px; "> <span id="icon" ><i class="fa-solid fa-thumbs-up"></i></span></button> </div>';
                 }
             }
             str += '</div>';
         
}
  
    document.getElementById("container1").innerHTML = str;
}
getAllCategories();

var clicks = 0;
function onClick(){
 clicks+=1;
  document.getElementById("clicks").innerHTML=clicks;
}
