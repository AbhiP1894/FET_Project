var qusetionsListResult = [];
var currentUser = null;
function updateAnswer(questionId, qusetionAnswer, condition){
    currentUser =  getCurrenyUserLogin();
    let resultObject  = qusetionsListResult.find(x => x.id === questionId);
    let qusetionAnswerArray = resultObject.Answer;
    let Comment = resultObject.Comment;
    let Like = resultObject.Like;
    if(condition == 1){
    qusetionAnswerArray.push({Answer: qusetionAnswer});
    } else if(condition == 2){
        Comment.push({Comment: qusetionAnswer});
    } else if(condition == 3){
        Like.push({Like: qusetionAnswer}); 
    }
    let payload = { 
    categoryName: resultObject.categoryName,
    qusetionName: resultObject.qusetionName,
    categoryId: resultObject.categoryId,
    approved: resultObject.approved,
    createdDate: resultObject.createdDate,
    Answer:qusetionAnswerArray,
    Comment:Comment,
    Like:Like,
    createdBy: currentUser.username
}
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open("PUT", 'http://localhost:5555/Qusetions/'+questionId, true);
    xmlHttp.setRequestHeader('Content-type','application/json; charset=utf-8');
    xmlHttp.onload = function () {
        var result = JSON.parse(xmlHttp.responseText);
    if(result){
        if(condition == 1){
        alert("Successfully Answered");
        } else if(condition == 2){
            alert("Successfully Commented");
        } else if(condition == 3){
            alert("Successfully Liked");
        }
        getQusetions();
    }
    }
    xmlHttp.send(JSON.stringify(payload));
}

function sendAnswer(questionId){
let answer = document.getElementById('answer'+questionId).value;
updateAnswer(questionId, answer, 1);
}
function sendComments(questionId){
    let comment = document.getElementById('comments'+questionId).value;
    updateAnswer(questionId, comment, 2);
}
function seneLikes(questionId){
    updateAnswer(questionId, 'Liked', 3);
}
function getQusetions() {
    qusetionsListResult = JSON.parse(QusetionsList());
    let str = '<div class="container1"><div class="row">';
    for (let i = 0; i < qusetionsListResult.length; i++) {
        if(qusetionsListResult[i].approved == 'Approved by Admin'){
        str += 
         '<div class="card col-md-4" style="text-align:left; margin-left:10px;">';
            
             str += '<p>' + (i+1) +'. Question</p>'+
                '<h5 class="card-title">Category: '+qusetionsListResult[i].categoryName +'</h5>'+
                '<p class="card-text">Question: '+qusetionsListResult[i].qusetionName +'</p>'+
                '<p class="card-text">Action: '+qusetionsListResult[i].approved +'</p>'+
                '<p class="card-text"><small class="text-muted"> Qusetion Created: '+timeDifference(new Date(), new Date(qusetionsListResult[i].createdDate)) +'</small></p>';
                if(qusetionsListResult[i].Answer.length > 0){
                    str += 'Answers: '  
                    for (let j = 0; j < qusetionsListResult[i].Answer.length; j++) {  
                        str +='<p>'+(j+1)+'. '+qusetionsListResult[i].Answer[j].Answer+' - Answered by - '+qusetionsListResult[i].createdBy+'</p>';

                    }
                }
                if(qusetionsListResult[i].Comment.length > 0){
                    str += 'Comments: '  
                    for (let j = 0; j < qusetionsListResult[i].Comment.length; j++) {  
                        str +='<p>'+(j+1)+'. '+qusetionsListResult[i].Comment[j].Comment+' - Comentted by - '+qusetionsListResult[i].createdBy+'</p>';

                    }
                }
                if(qusetionsListResult[i].Like.length > 0){
                    str += 'Likes: ' + qusetionsListResult[i].Like.length; 
                    for (let j = 0; j < qusetionsListResult[i].Like.length; j++) {  
                        str +='<p>'+(j+1)+'. Liked by - '+qusetionsListResult[i].createdBy+'</p>';

                    }
                }
                str +='<br>Answer:<br><textarea id="answer'+qusetionsListResult[i].id+'"></textarea>';
                str+='<br><button type="button" id="answer'+qusetionsListResult[i].id+'" onclick="sendAnswer('+qusetionsListResult[i].id+')">Send Answer</button>';
                str +='<br>Comments:<br><textarea id="comments'+qusetionsListResult[i].id+'"></textarea>';
                str+='<br><button type="button" id="comments'+qusetionsListResult[i].id+'" onclick="sendComments('+qusetionsListResult[i].id+')">Send Comments</button>';
                str+='<br><button id="like'+qusetionsListResult[i].id+'" onClick="seneLikes('+qusetionsListResult[i].id+')" class="btn bg-primary" style="margin-left:10px; height:30px; width:50px; "> <span id="icon" ><i class="fa-solid fa-thumbs-up"></i></span></button>';
                str += '</div>';
            }
            }
            str += '</div></div>';
           
 
    document.getElementById("qusetions").innerHTML = str;
}
getQusetions();
