package com.cybage.model;

public class BookTicket {
	
	private int bookid;
	private User pid;
	
	

}
