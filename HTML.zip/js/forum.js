var currentUser =null;
function createQusetion() {
    currentUser =  getCurrenyUserLogin();
    let category = document.getElementById("framework").value;
    let qusetion = document.getElementById("question").value;
    let catgoriesList = JSON.parse(categories());
    let resultObject = search(category, catgoriesList);
    let paylod = {
        "categoryId": resultObject.id,
        "categoryName": category,
        "qusetionName": qusetion,
        "approved": "Not Approved",
        "createdDate": new Date(),
        "Answer": [],
        "Comment":[],
        "Like":[],
        "createdBy": currentUser.username
    }
    checkLoginCredentials(paylod);
}

function checkLoginCredentials(paylod) {
    $.ajax({
        type: 'POST',
        url: questionUrl,
        data: paylod,
        dataType: "text",
        success: function(resultData) { 
            alert("Your qusetions send to admin but it is displayed after approval");
            window.open("home.html");
        }
  });
}

function categories() {
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open("GET", 'http://localhost:4444/Categories', false); // false for synchronous request
    xmlHttp.send(null);
    return xmlHttp.responseText;
}

function search(categoryName, inputArray) {
    let result = null;
    for (let i = 0; i < inputArray.length; i++) {
        if (inputArray[i].categoryName == categoryName) {
            result = inputArray[i];
            break;
        }
    }
    return result;
}

function getCurrentUser(){
    currentUser =  getCurrenyUserLogin();
   document.getElementById("currentUser").innerHTML = currentUser.name;
}

getCurrentUser();



