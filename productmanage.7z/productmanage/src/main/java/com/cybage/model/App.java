package com.cybage.model;

import com.cybage.utilities.DBUtil;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

     DBUtil db=new DBUtil();
     db.getConnection();
    
    }
}
