

import { Flight } from '../../utilities/flight';
import { FlightService } from './../../service/flight.service';
import { Component, OnInit } from '@angular/core';


import { Router } from '@angular/router';
import { Airline } from 'src/app/utilities/airline';




@Component({
  selector: 'app-flights',
  templateUrl: './flights.component.html',
  styleUrls: ['./flights.component.scss']
})
export class FlightsComponent implements OnInit {

  flight1: Flight = new Flight();
  searchText:any;


  constructor(private flightService:FlightService,
    private route: Router) { }

  flights: Flight[] = [];
  airlines: Airline[ ] = [ ];



  ngOnInit(): void {
    this.getFlights();
  }

  addFlight(): void {
    console.log(this.flight1);
    this.flightService.createFlight(this.flight1)
        .subscribe( data => {
          alert("Flight added to the list successfully.");
          this.route.navigate(['/', 'flights']);
        });
  };

  private getFlights(){
    this.flightService.getFlightList().subscribe(data => {
      this.flights = data;

    });
  }

  getFlightById(flight : Flight){
    this.flightService.getFlightById(flight.flightId).subscribe(data => {
      this.flights = data;

    });
  }

  deleteFlight(flight: Flight): void {
		this.flightService.deleteCustomers(flight)
		  .subscribe( data => {
			this.flights = this.flights.filter(u => u !== flight);
      alert("Flight Deleted Successfully!!")
		  })
	  };

}
