export class Airline {
  airlineId!: number;
   airlineName!: string;
    airlineNumber!: string;
}
