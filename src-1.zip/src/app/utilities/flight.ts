
// export class Flight {
//   flightId: number | undefined;
//   flightName: string | undefined;
//   departureDate: string | undefined;
//   departureTime: string | undefined;
//   arivalDate: number | undefined;
//   arivalTime: number | undefined;
//   source: number | undefined;
//   destination: number | undefined;
//   classType: string | undefined;
//   noOfStops: number | undefined;
//   price: number | undefined;
//   seatingCapacity: number | undefined;

import { Airline } from "./airline";

//   // public airline: { airlineId: number , airlineName: string , airlineNumber: string } | undefined;

// }


export class Flight {
  flightId!: number;
  flightName!: string;
  departureDate!: string;
  departureTime!: string;
  arivalDate!: number;
  arivalTime!: number;
  source!: number;
  destination!: number;
  classType!: string;
  noOfStops!: number;
  price!: number;
  seatingCapacity!: number;
  airline!: Airline;
  // airline!: { airlineId: number , airlineName: string , airlineNumber: string };
}
