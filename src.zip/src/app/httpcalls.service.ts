import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { Usermodel } from './registration/user-model';
@Injectable({
  providedIn: 'root'
})
export class HttpcallsService {
  private REST_API_SERVER = "http://localhost:";
  constructor(private httpClient: HttpClient) { }


  getUsers(){

  }

  createUser(payload: any): Observable<any>{
    const result = this.httpClient.post(this.REST_API_SERVER+"3000/Users", payload);
    return from(result);
  }
}
