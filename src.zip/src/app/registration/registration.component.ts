import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpcallsService } from '../httpcalls.service';
import { Usermodel } from './user-model';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  userModel = {
    Firstname: null,
    Lastname: null,
    Gender: null,
    State: null,
    City: null,
    DOB: null,
    EmailId: null,
    Password: null,
    Phonenumber: null,
  }
  constructor(private _router: Router,
    private httpServiceCall: HttpcallsService) { }

  ngOnInit(): void {
  }


  loginPage() {
    this._router.navigate(['/login']);
  }


  onSubmit() {
    if (this.userModel) {
      this.httpServiceCall.createUser(this.userModel).subscribe((data: any) => {
        if (data.id) {
          alert("Successfuly user created")
        }
      })
    } 
  }
}
