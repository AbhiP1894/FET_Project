export interface Usermodel{
    Firstname: string,
    Lastname: string,
    Gender: string,
    State: string,
    City: string,
    DOB: string,
    EmailId: string,
    Phonenumber: string,
}